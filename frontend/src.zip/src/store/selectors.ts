import { createSelector } from '@reduxjs/toolkit';
import type { RootState } from '@/store/rootReducer';
import type { AppState } from '@/store/types';

/** Puts the slices of all the features together in one `AppState` (only changes when one of the slices changes). */
export const selectAppState = createSelector(
  [
    (s: RootState) => s.auth, (s: RootState) => s.users, (s: RootState) => s.teams, (s: RootState) => s.workflows,
    (s: RootState) => s.leads, (s: RootState) => s.meetings, (s: RootState) => s.updates, (s: RootState) => s.tasks,
    (s: RootState) => s.tips, (s: RootState) => s.escalations, (s: RootState) => s.notifications,
  ],
  (auth, users, teams, workflows, leads, meetings, updates, tasks, tips, escalations, notifications): AppState => ({
    session: auth.session,
    loading: auth.loading,
    currentUserId: auth.currentUserId,
    users, teams, workflows, leads, meetings, updates, tasks, tips, escalations,
    notifications: notifications.items,
    badges: notifications.badges,
  }),
);
