import { Menu } from 'lucide-react';
import { useState } from 'react';
import { Sidebar } from '@/app/layout/Sidebar';
import { UserMenu } from '@/app/layout/UserMenu';
import { navBadges } from '@/app/navBadges';
import { NAV_ITEMS, type PageId } from '@/app/navigation';
import { NotificationsMenu } from '@/features/notifications/components/NotificationsMenu';
import { useStore } from '@/store/hooks';

export function AppShell({
  children,
  currentPage,
  onNavigate,
  onLogout,
}: {
  children: React.ReactNode;
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  onLogout: () => void;
}) {
  const { state } = useStore();
  const [menuOpen, setMenuOpen] = useState(false);

  const currentUser = state.users.find(u => u.id === state.currentUserId);
  if (!currentUser) return null;

  // a notification with a userId belongs to that person only
  const myNotifications = state.notifications.filter(n => !n.userId || n.userId === currentUser.id);
  const badges = navBadges(state, currentUser);
  const unreadCount = myNotifications.filter(n => !n.read).length;

  const navItems = NAV_ITEMS.filter(item => item.roles.includes(currentUser.role));

  const team = state.teams.find(t => t.id === currentUser.teamId);

  return (
    <div className="flex h-screen h-dvh bg-slate-50 text-slate-900">
      <Sidebar
        navItems={navItems} currentPage={currentPage}
        onNavigate={page => { onNavigate(page); setMenuOpen(false); }}
        badges={badges} currentUser={currentUser} onLogout={onLogout}
        open={menuOpen} onClose={() => setMenuOpen(false)}
      />
      {menuOpen && <div className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-sm lg:hidden animate-fade-in" onClick={() => setMenuOpen(false)} aria-hidden="true" />}

      {/* Main content */}
      <div className="flex-1 min-w-0 flex flex-col overflow-hidden">
        {/* Top bar */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between gap-2 px-3 sm:px-6 shrink-0">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <button
              onClick={() => setMenuOpen(true)}
              className="lg:hidden w-10 h-10 -ml-1 flex items-center justify-center rounded-lg text-slate-600 hover:bg-slate-100 shrink-0"
              aria-label="Open menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="text-base sm:text-lg font-bold tracking-tight text-slate-900 truncate">
              {navItems.find(n => n.id === currentPage)?.label}
            </h1>
            {team && currentUser.role === 'agent' && (
              <span className="hidden sm:inline text-xs font-medium text-slate-600 bg-slate-100 px-2.5 py-1 rounded-full shrink-0">{team.name}</span>
            )}
          </div>

          <div className="flex items-center gap-1 sm:gap-3 shrink-0">
            <NotificationsMenu notifications={myNotifications} unreadCount={unreadCount} onNavigate={onNavigate} />

            <UserMenu currentUser={currentUser} onLogout={onLogout} />
          </div>
        </header>

        {/* PageId content */}
        <main className="flex-1 overflow-y-auto scrollbar-thin">
          {children}
        </main>
      </div>
    </div>
  );
}
