/** Put the items in the list: the ones already there (same id) are replaced, new ones go first. Meant for Redux reducers (Immer drafts). */
export function upsertById<T extends { id: string }>(list: T[], items: T[]) {
  for (const item of items) {
    const i = list.findIndex(x => x.id === item.id);
    if (i >= 0) list[i] = item; else list.unshift(item);
  }
}
