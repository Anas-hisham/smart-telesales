import { reportError } from '@/shared/api/apiErrors';

/** Run an API call; on failure show the error banner and return `fallback`. */
export async function attempt<T, F = undefined>(fn: () => Promise<T>, fallback?: F): Promise<T | F | undefined> {
  try { return await fn(); } catch (e) { reportError(e); return fallback; }
}
