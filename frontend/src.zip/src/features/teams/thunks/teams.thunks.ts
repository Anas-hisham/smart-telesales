import { teamsApi } from '@/features/teams/api/teams.api';
import { setTeams } from '@/features/teams/slice/teams.slice';
import { usersUpserted } from '@/features/users/slice/users.slice';
import { refreshCollections } from '@/features/workspace/thunks/workspace.thunks';
import { attempt } from '@/shared/api/attempt';
import type { AppThunk } from '@/store/types';

export const loadTeams = (): AppThunk => async dispatch => {
  const teams = await attempt(() => teamsApi.list());
  if (teams) dispatch(setTeams(teams));
};

export const moveAgentToTeam = (p: { agentId: string; toTeamId: string }): AppThunk<boolean> => async dispatch => {
  const r = await attempt(() => teamsApi.moveAgent(p.agentId, p.toTeamId));
  if (!r) return false;
  dispatch(setTeams(r.teams));
  dispatch(usersUpserted([r.agent]));
  return true;
};

export const assignTeamToManager = (p: { teamId: string; managerId: string }): AppThunk<boolean> => async dispatch => {
  const r = await attempt(() => teamsApi.setManager(p.teamId, p.managerId || null));
  if (!r) return false;
  await Promise.all([dispatch(refreshCollections(['users'])), dispatch(loadTeams())]);
  return true;
};

export const setAgentQuality = (p: { agentId: string; qualityId: string }): AppThunk<boolean> => async dispatch => {
  const u = await attempt(() => teamsApi.setQuality(p.agentId, p.qualityId || null));
  if (u) dispatch(usersUpserted([u]));
  return !!u;
};
