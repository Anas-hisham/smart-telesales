/** Percent with one decimal (0 when the denominator is 0). */
export const pct = (n: number, d: number) => (d > 0 ? Math.round((n / d) * 1000) / 10 : 0);
