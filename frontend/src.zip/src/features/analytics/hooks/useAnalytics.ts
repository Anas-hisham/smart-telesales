import { useEffect, useState } from 'react';
import { analyticsApi } from '@/features/analytics/api/analytics.api';
import type { AnalyticsReport, AnalyticsRow, DateRange, GroupRow, PeriodPreset } from '@/features/analytics/types/analytics.types';
import { errorText } from '@/shared/api/client';

/** The server sends rates as fractions (0.4553); the screen shows percents with one decimal (45.5). */
export const toPct = (x: number) => Math.round(x * 1000) / 10;

export const groupRow = (r: AnalyticsRow): GroupRow => ({
  ...r, answerRate: toPct(r.answerRate), reachRate: toPct(r.reachRate), conversion: toPct(r.conversion), reachToSale: toPct(r.reachToSale),
});

/** GET /analytics: the server counts everything for the signed-in person's scope (own numbers, own team, or own teams). */
export function useAnalytics(preset: PeriodPreset, custom: DateRange, campaign: string) {
  const [report, setReport] = useState<AnalyticsReport | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let stale = false;
    setLoading(true);
    const t = setTimeout(() => {       // a moment after the date inputs change
      analyticsApi.report({
        preset, campaign: campaign === 'all' ? undefined : campaign,
        ...(preset === 'custom' ? { from: custom.from || custom.to, to: custom.to || custom.from } : {}),
      })
        .then(r => { if (!stale) { setReport(r); setError(''); } })
        .catch(e => { if (!stale) setError(errorText(e)); })
        .finally(() => { if (!stale) setLoading(false); });
    }, 200);
    return () => { stale = true; clearTimeout(t); };
  }, [preset, custom.from, custom.to, campaign]);

  return { report, error, loading };
}
