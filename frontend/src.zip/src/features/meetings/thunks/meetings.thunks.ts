import { meetingsApi } from '@/features/meetings/api/meetings.api';
import { meetingsUpserted } from '@/features/meetings/slice/meetings.slice';
import type { MeetingInput } from '@/features/meetings/types/meetings.types';
import { attempt } from '@/shared/api/attempt';
import type { AppThunk } from '@/store/types';

export const createMeeting = (m: MeetingInput): AppThunk<boolean> => async dispatch => {
  const r = await attempt(() => meetingsApi.create(m));
  if (r) dispatch(meetingsUpserted([r]));
  return !!r;
};
export const updateMeeting = (p: { meetingId: string; updates: Record<string, unknown> }): AppThunk<boolean> => async dispatch => {
  const r = await attempt(() => meetingsApi.update(p.meetingId, p.updates));
  if (r) dispatch(meetingsUpserted([r]));
  return !!r;
};
/** The old meeting becomes "rescheduled" and a new one is created (one step on the server). */
export const rescheduleMeeting = (p: { meetingId: string; date: string; time: string; duration?: number; notes?: string }): AppThunk<boolean> => async dispatch => {
  const { meetingId, ...body } = p;
  const r = await attempt(() => meetingsApi.reschedule(meetingId, body));
  if (r) dispatch(meetingsUpserted([r.old, r.new]));
  return !!r;
};
