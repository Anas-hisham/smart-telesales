import { teamUpdatesApi } from '@/features/team-updates/api/teamUpdates.api';
import { updatesUpserted } from '@/features/team-updates/slice/teamUpdates.slice';
import { refreshCollections } from '@/features/workspace/thunks/workspace.thunks';
import { attempt } from '@/shared/api/attempt';
import type { AppThunk } from '@/store/types';

export const postTeamUpdate = (u: { audience: string; title: string; content: string }): AppThunk<boolean> => async dispatch => {
  const r = await attempt(() => teamUpdatesApi.create({ audience: u.audience, title: u.title.trim(), content: u.content.trim() }));
  if (r) dispatch(updatesUpserted([r]));
  return !!r;
};
export const acknowledgeTeamUpdate = (updateId: string): AppThunk<boolean> => async dispatch => {
  const r = await attempt(() => teamUpdatesApi.acknowledge(updateId));
  if (r) { dispatch(updatesUpserted([r])); void dispatch(refreshCollections(['notifications'])); }
  return !!r;
};
export const markUpdatesSeen = (_userId?: string): AppThunk => async dispatch => {
  if (await attempt(async () => { await teamUpdatesApi.seen(); return true; })) await dispatch(refreshCollections(['updates']));
};
