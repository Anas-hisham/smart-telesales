/** Who an update is addressed to. The author is never a recipient of his own update. */
import type { TeamUpdate } from '@/features/team-updates/types/teamUpdates.types';
import type { Team } from '@/features/teams/types/teams.types';
import { lobOf } from '@/features/teams/utils/orgRules';
import type { User } from '@/features/users/types/users.types';

export function updateRecipients(update: Pick<TeamUpdate, 'audience' | 'teamId' | 'authorId' | 'recipients'>, users: User[], teams: Team[]): User[] {
  // the server already worked out who the update reached
  if (update.recipients) return update.recipients.map(r => users.find(u => u.id === r.id)).filter((u): u is User => !!u);

  // an Operation Manager runs one line of business: his updates reach the people of that LOB only
  const author = users.find(u => u.id === update.authorId);
  const lob = author?.role === 'operation_manager' ? author.lob ?? '' : '';
  const inScope = (u: User) => !lob || lobOf(users, teams, u) === lob;
  const pool = (() => {
    switch (update.audience) {
      case 'all': return users.filter(u => (u.role === 'team_leader' || u.role === 'agent' || u.role === 'quality') && inScope(u));
      case 'team_leaders': return users.filter(u => u.role === 'team_leader' && inScope(u));
      case 'quality': return users.filter(u => u.role === 'quality' && inScope(u));
      case 'specific_team': {
        const team = teams.find(t => t.id === update.teamId);
        return users.filter(u => !!team && team.agentIds.includes(u.id));
      }
    }
  })();
  return pool.filter(u => u.id !== update.authorId);
}
