import { createSlice, type PayloadAction } from '@reduxjs/toolkit';
import { sessionEnded, sessionReady } from '@/features/auth/slice/auth.slice';
import type { User } from '@/features/users/types/users.types';
import { upsertById } from '@/shared/lib/upsertById';

const usersSlice = createSlice({
  name: 'users',
  initialState: [] as User[],
  reducers: {
    setUsers: (_state, a: PayloadAction<User[]>) => a.payload,
    usersUpserted(state, a: PayloadAction<User[]>) { upsertById(state, a.payload); },
  },
  extraReducers: builder => {
    builder
      .addCase(sessionReady, (state, a) => [a.payload.user, ...state.filter(u => u.id !== a.payload.user.id)])
      .addCase(sessionEnded, () => []);
  },
});

export const { setUsers, usersUpserted } = usersSlice.actions;
export default usersSlice.reducer;
