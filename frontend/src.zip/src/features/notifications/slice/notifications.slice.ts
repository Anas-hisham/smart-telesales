import { createSlice, type PayloadAction } from '@reduxjs/toolkit';
import { sessionEnded, sessionReady } from '@/features/auth/slice/auth.slice';
import type { Badges, Notification } from '@/features/notifications/types/notifications.types';

interface NotificationsState {
  items: Notification[];
  /** The numbers shown next to the menu items (computed by the server). */
  badges: Badges;
}

const NO_BADGES: Badges = { updates: 0, tasks: 0, tips: 0, escalations: 0 };
const initialState = (): NotificationsState => ({ items: [], badges: NO_BADGES });

const notificationsSlice = createSlice({
  name: 'notifications',
  initialState,
  reducers: {
    setNotifications(state, a: PayloadAction<Notification[]>) { state.items = a.payload; },
    setBadges(state, a: PayloadAction<Badges>) { state.badges = a.payload; },
    notificationsRead(state, a: PayloadAction<string[] | 'all'>) {
      for (const n of state.items) if (a.payload === 'all' || a.payload.includes(n.id)) n.read = true;
    },
  },
  extraReducers: builder => {
    builder
      .addCase(sessionReady, (state, a) => { if (a.payload.badges) state.badges = a.payload.badges; })
      .addCase(sessionEnded, () => initialState());
  },
});

export const { setNotifications, setBadges, notificationsRead } = notificationsSlice.actions;
export default notificationsSlice.reducer;
