import type { UnknownAction } from '@reduxjs/toolkit';
import { leadPoolApi } from '@/features/leads/api/leadPool.api';
import { leadsApi } from '@/features/leads/api/leads.api';
import { callLogMerged, leadsRemoved, leadsReplaced, leadUpserted } from '@/features/leads/slice/leads.slice';
import type { CallLog, CallType } from '@/features/leads/types/callLog.types';
import { leadFromApi } from '@/features/leads/utils/leadMappers';
import { attempt } from '@/shared/api/attempt';
import { reportError, reportNotice } from '@/shared/api/apiErrors';
import type { RootState } from '@/store/rootReducer';
import type { AppThunk } from '@/store/types';

// ───────────────────────────── loading ─────────────────────────────
/** Every page of the agent's lead list. */
async function fetchAllLeads() {
  const out = [];
  for (let page = 1; ; page++) {
    const r = await leadsApi.list({ pageSize: 200, page });
    out.push(...r.items);
    if (out.length >= r.total || r.items.length === 0) return out;
  }
}

/** Agents only: load the whole lead list of the signed-in agent. */
export const refreshLeads = (): AppThunk => async (dispatch, getState) => {
  const { users, auth } = getState();
  if (users.find(u => u.id === auth.currentUserId)?.role !== 'agent') return;
  const items = await attempt(fetchAllLeads);
  if (items) dispatch(leadsReplaced(items.map(l => leadFromApi(l))));
};

/** Open lead: load its call logs / history / previous rounds. */
export const loadLeadDetail = (leadId: string): AppThunk => async dispatch => {
  const d = await attempt(() => leadsApi.detail(leadId));
  if (d) dispatch(leadUpserted(leadFromApi(d)));
};

// ───────────────────────────── a lead (agent) ─────────────────────────────
/**
 * Store a lead the server sent back. If the server just released it (the last touch point was done, so it went
 * back to the pool), it leaves my list at once and the agent is told why.
 */
const upsertLead = (dispatch: (a: UnknownAction) => unknown, getState: () => RootState, apiLead: Parameters<typeof leadFromApi>[0]) => {
  if (apiLead.removedFromQueue) {
    dispatch(leadsRemoved([apiLead.id]));
    reportNotice(`${apiLead.companyName} (${apiLead.leadCode}) finished all its steps and went back to the pool.`);
    return;
  }
  dispatch(leadUpserted(leadFromApi(apiLead, getState().leads.find(l => l.id === apiLead.id))));
};

export const completeTouchPoint = (p: { leadId: string; order: number }): AppThunk<boolean> => async (dispatch, getState) => {
  const l = await attempt(() => leadsApi.step(p.leadId, p.order, 'complete'));
  if (l) upsertLead(dispatch, getState, l);
  return !!l;
};
export const skipTouchPoint = (p: { leadId: string; order: number }): AppThunk<boolean> => async (dispatch, getState) => {
  const l = await attempt(() => leadsApi.step(p.leadId, p.order, 'skip'));
  if (l) upsertLead(dispatch, getState, l);
  return !!l;
};
export const restoreSkippedTouchPoint = (p: { leadId: string; order: number }): AppThunk<boolean> => async (dispatch, getState) => {
  const l = await attempt(() => leadsApi.step(p.leadId, p.order, 'restore'));
  if (l) upsertLead(dispatch, getState, l);
  return !!l;
};

type CallInput = { type: CallType; description: string; touchPointOrder: number; reason?: CallLog['reason'] };
const logCall = (leadId: string, log: CallInput, completeTouchPoint: boolean): AppThunk<boolean> => async (dispatch, getState) => {
  const r = await attempt(() => leadsApi.logCall(leadId, { ...log, description: log.description.trim(), completeTouchPoint }));
  if (!r) return false;
  upsertLead(dispatch, getState, r.lead);
  dispatch(callLogMerged({ leadId, log: r.callLog }));
  return true;
};
/** One atomic call on the server: the call log and the completed step cannot get out of sync. */
export const logCallAndCompleteTouchPoint = (p: { leadId: string; log: CallInput }) => logCall(p.leadId, p.log, true);
export const addCallLogWithoutCompletingTouchPoint = (p: { leadId: string; log: CallInput }) => logCall(p.leadId, p.log, false);

export const editCallLog = (p: { leadId: string; logId: string; callType: CallType; description: string }): AppThunk<boolean> => async (dispatch, getState) => {
  const r = await attempt(() => leadsApi.editCall(p.leadId, p.logId, { type: p.callType, description: p.description.trim() }));
  if (!r) return false;
  upsertLead(dispatch, getState, r.lead);
  dispatch(callLogMerged({ leadId: p.leadId, log: r.callLog }));
  return true;
};

export const stopLeadWorkflow = (leadId: string): AppThunk<boolean> => async (dispatch, getState) => {
  const l = await attempt(() => leadsApi.stop(leadId));
  if (l) upsertLead(dispatch, getState, l);
  return !!l;
};
export const resumeLeadWorkflow = (leadId: string): AppThunk<boolean> => async (dispatch, getState) => {
  const l = await attempt(() => leadsApi.resume(leadId));
  if (l) upsertLead(dispatch, getState, l);
  return !!l;
};
/** The lead leaves my queue and goes back to the pool (agents can remove a lead, never delete it; a recorded sale does not block this). */
export const removeLeadFromAgentQueue = (leadId: string): AppThunk<boolean> => async dispatch => {
  const r = await attempt(() => leadsApi.remove(leadId));
  if (r) dispatch(leadsRemoved([leadId]));
  return !!r;
};

/** Take leads from the pool by their ids (the ids come from POST /lead-pool/preview). */
export const takeLeadsFromPool = (leadIds: string[]): AppThunk<boolean> => async (dispatch, getState) => {
  const r = await attempt(() => leadPoolApi.take(leadIds));
  if (!r) return false;
  for (const l of r.taken) upsertLead(dispatch, getState, l);
  if (r.skipped.length) reportError(`${r.skipped.length} lead${r.skipped.length === 1 ? ' was' : 's were'} not taken: somebody else got ${r.skipped.length === 1 ? 'it' : 'them'} first.`);
  return true;
};

/** Team Leader / Operation Manager: give a lead to another agent (a new round starts). */
export const transferLeadToAgent = (p: { leadId: string; newAgentId: string }): AppThunk<boolean> => async () => {
  const l = await attempt(() => leadsApi.transfer(p.leadId, p.newAgentId));
  return !!l;
};
