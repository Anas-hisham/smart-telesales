import { createSlice, type PayloadAction } from '@reduxjs/toolkit';
import { sessionEnded } from '@/features/auth/slice/auth.slice';
import type { CallLog } from '@/features/leads/types/callLog.types';
import type { Lead } from '@/features/leads/types/leads.types';

/** Agents only: the leads of the signed-in agent. */
const leadsSlice = createSlice({
  name: 'leads',
  initialState: [] as Lead[],
  reducers: {
    /** The agent's whole lead list. Call logs / history already loaded are kept. */
    leadsReplaced(state, a: PayloadAction<Lead[]>) {
      const old = new Map(state.map(l => [l.id, l]));
      const next = a.payload.map(l => {
        const p = old.get(l.id);
        return p && p.detailLoaded && !l.detailLoaded ? { ...l, callLogs: p.callLogs, history: p.history, previousAssignments: p.previousAssignments, detailLoaded: p.detailLoaded } : l;
      });
      state.splice(0, state.length, ...next);
    },
    leadUpserted(state, a: PayloadAction<Lead>) {
      const i = state.findIndex(l => l.id === a.payload.id);
      if (i >= 0) state[i] = a.payload; else state.unshift(a.payload);
    },
    leadsRemoved(state, a: PayloadAction<string[]>) {
      const ids = new Set(a.payload);
      return state.filter(l => !ids.has(l.id));
    },
    /** A call just saved: show it at once in the lead that is already open. */
    callLogMerged(state, a: PayloadAction<{ leadId: string; log: CallLog }>) {
      const l = state.find(x => x.id === a.payload.leadId);
      if (!l) return;
      const i = l.callLogs.findIndex(c => c.id === a.payload.log.id);
      if (i >= 0) l.callLogs[i] = a.payload.log; else l.callLogs.push(a.payload.log);
    },
  },
  extraReducers: builder => {
    builder.addCase(sessionEnded, () => []);
  },
});

export const { leadsReplaced, leadUpserted, leadsRemoved, callLogMerged } = leadsSlice.actions;
export default leadsSlice.reducer;
