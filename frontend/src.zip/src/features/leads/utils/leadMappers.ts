import type { ApiLead, ApiLeadDetail, Lead } from '@/features/leads/types/leads.types';

/**
 * Server lead -> the Lead the UI uses.
 * The lists do not carry call logs / history: they stay as they were (empty until GET /leads/:id is loaded).
 */
export function leadFromApi(d: ApiLead | ApiLeadDetail, prev?: Lead): Lead {
  const full = 'callLogs' in d;
  const { upcomingMeeting: _um, ...rest } = d as ApiLeadDetail;
  return {
    ...rest,
    agentId: d.agentId ?? '',
    callLogs: full ? (d as ApiLeadDetail).callLogs : prev?.callLogs ?? [],
    history: full ? (d as ApiLeadDetail).history : prev?.history ?? [],
    previousAssignments: full ? (d as ApiLeadDetail).previousAssignments : prev?.previousAssignments,
    detailLoaded: full ? true : prev?.detailLoaded,
  } as Lead;
}
