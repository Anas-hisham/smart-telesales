import { MAX_GAP_DAYS, MAX_TOUCH_POINTS } from '@/features/campaigns/constants/campaigns.constants';
import type { WorkflowDraft } from '@/features/campaigns/types/campaigns.types';
import { cleanCampaignCode } from '@/features/campaigns/utils/workflowDraft';

/** Returns a problem text, or '' when the draft can be saved. `otherCodes` = codes of the OTHER campaigns. */
export function validateWorkflowDraft(d: WorkflowDraft, otherCodes: string[]): string {
  const code = cleanCampaignCode(d.campaignCode);
  if (!code) return 'Campaign code is required';
  if (otherCodes.some(c => c.toUpperCase() === code)) return 'This campaign code already exists';
  if (!d.name.trim()) return 'Campaign name is required';
  if (d.steps.length === 0) return 'Add at least one touch point';
  if (d.steps.length > MAX_TOUCH_POINTS) return `A campaign can have at most ${MAX_TOUCH_POINTS} touch points`;
  for (let i = 0; i < d.steps.length; i++) {
    const s = d.steps[i];
    if (s.type !== 'call' && s.type !== 'email') return `Touch point ${i + 1}: choose call or email`;
    if (!s.label.trim()) return `Touch point ${i + 1}: write a name for it`;
    if (!Number.isInteger(s.gapDays) || s.gapDays < 0 || s.gapDays > MAX_GAP_DAYS) return `Touch point ${i + 1}: days must be a whole number from 0 to ${MAX_GAP_DAYS}`;
  }
  return '';
}
