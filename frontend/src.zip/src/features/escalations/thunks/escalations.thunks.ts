import { escalationsApi } from '@/features/escalations/api/escalations.api';
import { refreshCollections } from '@/features/workspace/thunks/workspace.thunks';
import { attempt } from '@/shared/api/attempt';
import type { AppThunk } from '@/store/types';

export const createEscalation = (e: { aboutId: string; recipientId: string; title: string; details: string }): AppThunk<boolean> => async dispatch => {
  const r = await attempt(() => escalationsApi.create(e));
  if (r) await dispatch(refreshCollections(['escalations']));
  return !!r;
};
export const forwardEscalation = (p: { id: string; toId: string; note?: string }): AppThunk<boolean> => async dispatch => {
  const r = await attempt(() => escalationsApi.forward(p.id, { toId: p.toId, note: p.note }));
  if (r) await dispatch(refreshCollections(['escalations']));
  return !!r;
};
export const resolveEscalation = (p: { id: string; note?: string }): AppThunk<boolean> => async dispatch => {
  const r = await attempt(() => escalationsApi.resolve(p.id, { note: p.note }));
  if (r) await dispatch(refreshCollections(['escalations']));
  return !!r;
};
