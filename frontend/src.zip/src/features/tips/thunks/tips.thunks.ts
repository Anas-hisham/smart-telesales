import { tipsApi } from '@/features/tips/api/tips.api';
import { tipsUpserted } from '@/features/tips/slice/tips.slice';
import { refreshCollections } from '@/features/workspace/thunks/workspace.thunks';
import { attempt } from '@/shared/api/attempt';
import type { AppThunk } from '@/store/types';

export const sendTips = (t: { agentIds: string[]; title: string; content: string }): AppThunk<boolean> => async dispatch => {
  const r = await attempt(() => tipsApi.create(t));
  if (r) dispatch(tipsUpserted(r.created));
  return !!r;
};
export const acknowledgeTip = (id: string): AppThunk<boolean> => async dispatch => {
  const r = await attempt(() => tipsApi.acknowledge(id));
  if (r) dispatch(tipsUpserted([r]));
  return !!r;
};
export const markTipsSeen = (_userId?: string): AppThunk => async dispatch => {
  if (await attempt(async () => { await tipsApi.seen(); return true; })) await dispatch(refreshCollections(['tips']));
};
