import { createSlice, type PayloadAction } from '@reduxjs/toolkit';
import { sessionEnded } from '@/features/auth/slice/auth.slice';
import type { Tip } from '@/features/tips/types/tips.types';
import { upsertById } from '@/shared/lib/upsertById';

const tipsSlice = createSlice({
  name: 'tips',
  initialState: [] as Tip[],
  reducers: {
    setTips: (_state, a: PayloadAction<Tip[]>) => a.payload,
    tipsUpserted(state, a: PayloadAction<Tip[]>) { upsertById(state, a.payload); },
  },
  extraReducers: builder => {
    builder.addCase(sessionEnded, () => []);
  },
});

export const { setTips, tipsUpserted } = tipsSlice.actions;
export default tipsSlice.reducer;
