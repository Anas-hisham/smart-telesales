import { tasksApi } from '@/features/tasks/api/tasks.api';
import { tasksUpserted } from '@/features/tasks/slice/tasks.slice';
import { refreshCollections } from '@/features/workspace/thunks/workspace.thunks';
import { attempt } from '@/shared/api/attempt';
import type { AppThunk } from '@/store/types';

export const createTask = (t: { title: string; description?: string; deadline: string; assignedTo: string[] }): AppThunk<boolean> => async dispatch => {
  const r = await attempt(() => tasksApi.create({ title: t.title.trim(), description: t.description?.trim() || undefined, deadline: t.deadline, assignedTo: t.assignedTo }));
  if (r) dispatch(tasksUpserted([r]));
  return !!r;
};
export const toggleTaskCompletion = (p: { taskId: string; userId?: string }): AppThunk<boolean> => async dispatch => {
  const r = await attempt(() => tasksApi.toggle(p.taskId));
  if (r) dispatch(tasksUpserted([r]));
  return !!r;
};
export const markTasksSeen = (_userId?: string): AppThunk => async dispatch => {
  if (await attempt(async () => { await tasksApi.seen(); return true; })) await dispatch(refreshCollections(['tasks']));
};
